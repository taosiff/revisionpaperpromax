========================================================================
OVERLEAF COMPILATION & SUBMISSION PACKAGE
PLOS ONE REVISION: ADOLESCENT ANXIETY PROGNOSTIC BENCHMARK
========================================================================

HOW TO COMPILE ON OVERLEAF:
1. Go to Overleaf (https://www.overleaf.com)
2. Click "New Project" -> "Upload Project"
3. Select this .zip file. Overleaf will unpack all files automatically.
4. Hit "Recompile" (Ctrl+Enter / Cmd+Enter). It compiles with zero errors!

DOCUMENTS INCLUDED IN THIS PACKAGE:
------------------------------------------------------------------------
1. main.tex:
   - Primary Clean Revised Manuscript (PLOS ONE template v3.7).
   - Set as default main document so Overleaf compiles on first click.

2. plos_withoutH.tex:
   - Identical unhighlighted manuscript for final journal submission.

3. plos_latex_HIGHLIGHT.tex:
   - Highlighted Revised Manuscript with yellow highlights (\hl{...})
     displaying all text revisions for the editors and reviewers.
   - To compile this version on Overleaf:
     Click "Menu" (top-left) -> Change "Main document" to "plos_latex_HIGHLIGHT.tex" -> Recompile.

4. plos_bibtex_sample.bib:
   - Complete BibTeX bibliography with all 28 cited references matched.

5. plos2025.bst:
   - Official PLOS ONE Vancouver-style bibliography format.

6. Figures (300 DPI PNGs):
   - Included both in the root directory and in the /figures/ folder:
     * Fig 1: Overall Multimodal Architecture Framework
     * Fig 2: Module 1 Structural Neuroimaging Pipeline (Med3D ResNet-18)
     * Fig 3: Module 2 Longitudinal Anxiety Symptomatology Pipeline
     * Fig 4: Deep Feature-Tokenizer ProtoNet Architecture
     * Fig 5: Multimodal Late Fusion Architecture & Decision Calibration
     * Fig 6: Test Cohort Confusion Matrix (n=62, tau*=0.56)
     * Fig 7: Multimodal Ablation Hierarchy & Ensembling Gain
     * Fig 8: 95% Family-Cluster Bootstrap Confidence Intervals
     * Fig 9: Module 2 SHAP Beeswarm Summary Plot
     * Fig 10: Module 2 Feature Importance Ranked Bar Chart
     * Fig 11: Module 3 SHAP Beeswarm Summary Plot
     * Fig 12: Module 3 Feature Importance Ranked Bar Chart
     * Fig_ROC_PR_Curves: Held-Out Prospective Test ROC & PR Curves
     * Fig_Cross_Modal_Attention: Cross-Modal Attention Matrix & Pooling

OVERLEAF SETTINGS:
- Compiler: pdfLaTeX (default)
- TeX Live version: 2024 or 2023
========================================================================
